﻿namespace Dominio.Modelo
{
    public class Produto
    {
        public int Produtoid { get; set; }
        public int Filialid { get; set; }
        public string Nome { get; set; }
        public decimal valor { get; set; }
    }
}
