﻿namespace Dominio.Modelo
{
    public class Filial
    {
        public int Filialid { get; set; }
        public string Nome { get; set; }
    }
}
