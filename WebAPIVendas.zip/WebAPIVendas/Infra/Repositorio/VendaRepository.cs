﻿using Dominio.Interface.Repositorio;
using Dominio.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra.Repositorio
{
    public class VendaRepository : IVendaRepository
    {
        public void Atualizar(Venda venda)
        {
            throw new NotImplementedException();
        }

        public void Cadastrar(Venda venda)
        {
            throw new NotImplementedException();
        }

        public void CarregarDados()
        {
            throw new NotImplementedException();
        }

        public void Excluir(int Vendaid)
        {
            throw new NotImplementedException();
        }

        public List<Venda> Listar()
        {
            throw new NotImplementedException();
        }

        public Venda PesquisaPorId(int Vendaid)
        {
            throw new NotImplementedException();
        }
    }
}
