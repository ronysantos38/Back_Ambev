﻿using Dominio.Interface.Repositorio;
using Dominio.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infra.Repositorio
{
    public class VendaRealizadaRepository : IVendaRealizadaRepository
    {
        public void Atualizar(VendaRealizada venda)
        {
            throw new NotImplementedException();
        }

        public void Cadastrar(VendaRealizada venda)
        {
            throw new NotImplementedException();
        }

        public void CarregarDados()
        {
            throw new NotImplementedException();
        }

        public void Excluir(int Vendaid)
        {
            throw new NotImplementedException();
        }

        public List<VendaRealizada> Listar()
        {
            throw new NotImplementedException();
        }

        public VendaRealizada PesquisaPorId(int Vendaid)
        {
            throw new NotImplementedException();
        }
    }
}